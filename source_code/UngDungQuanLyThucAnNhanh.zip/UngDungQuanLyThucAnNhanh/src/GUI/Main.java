package GUI;

import UTIL.MyDBConnection;

public class Main 
{
    public static void main(String[] args) throws Exception{     
        
        //Tạo connection
        //MyDBConnection connect = new MyDBConnection("localhost", "root", "", "test");       
        
        FormBanHang vd = new FormBanHang();
    }
}
