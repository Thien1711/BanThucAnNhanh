package UTIL;

public class General {
    public static String CURRENT_USER = "";
    public static int CURRENT_ROLE = 0;
}
